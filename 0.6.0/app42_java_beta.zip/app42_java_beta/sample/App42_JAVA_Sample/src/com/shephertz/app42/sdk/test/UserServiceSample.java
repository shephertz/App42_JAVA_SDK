package com.shephertz.app42.sdk.test;

import com.shephertz.app42.paas.sdk.java.App42BadParameterException;
import com.shephertz.app42.paas.sdk.java.App42Exception;
import com.shephertz.app42.paas.sdk.java.App42SecurityException;
import com.shephertz.app42.paas.sdk.java.ServiceAPI;
import com.shephertz.app42.paas.sdk.java.user.User;

public class UserServiceSample {
	
	/**
	 * Main Method To Create App42 User on Cloud
	 * @param args
	 */
	public static void main(String[] args) {
		createUser();
	}
	
	/**
	 * Test Method for creating the User in App42 Cloud. 
	 */
	public static void createUser() {
		// Enter your Public Key and Private Key Here in Constructor. You can 
		// get it once you will create a app in app42 console
		ServiceAPI sp = new ServiceAPI(
				"86a1c98e4baeac83743da42e4d97e7977210c85fcd47a47ace0324efa853ea51",
				"53508e2ae1dd4d8d575d1979f2765ccc7ed2d5bfb4b4c2783c2131607e22976c");
		// Create Instance of User Service
		User user = sp.buildUser();
		String response = null;
		// create user or call other available method on the user service
		// reference
		try {
			System.out.println(" Starting User Creation test");
			response = user.createUser("test.app123", "67899",
					"test.app@shephertz.com");
		} catch (App42BadParameterException ex) {
			// Exception Caught
			// Check if User already Exist by checking app error code
			if (ex.getAppErrorCode() == 2001) {
				// Do exception Handling for Already created User.
			}
		} catch (App42SecurityException ex) {
			// Exception Caught
			// Check for authorization Error due to invalid Public/Private Key
			if (ex.getAppErrorCode() == 1401) {
				// Do exception Handling here
			}
		} catch (App42Exception ex) {
			// Exception Caught due to other Validation
		}
		// Render the JSON response. This will return the Successful created
		// User response
		System.out.println(response);

	}

}
